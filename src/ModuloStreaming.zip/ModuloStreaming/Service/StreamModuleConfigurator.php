<?php

namespace App\ModuloStreaming\Service;

use App\ModuloCore\Entity\MenuElement;
use App\ModuloCore\Entity\Modulo;
use Doctrine\ORM\EntityManagerInterface;

class StreamingModuleConfigurator
{
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    public function install(): void
    {
        // Verificar si el módulo ya está instalado
        $moduloRepository = $this->entityManager->getRepository(Modulo::class);
        $existingModulo = $moduloRepository->findOneBy(['nombre' => 'Streaming']);
        
        if ($existingModulo) {
            // Si ya existe, simplemente actualizamos su estado a activo
            $existingModulo->setEstado(true);
            $this->entityManager->flush();
            return;
        }
        
        // Crear el módulo
        $modulo = new Modulo();
        $modulo->setNombre('Streaming');
        $modulo->setDescripcion('Módulo para gestionar y reproducir contenido en streaming');
        $modulo->setIcon('fas fa-play-circle');
        $modulo->setRuta('/streaming');
        $modulo->setEstado(true);
        $modulo->setInstallDate(new \DateTimeImmutable());
        
        $this->entityManager->persist($modulo);
        
        // Crear elementos de menú para el módulo
        // Menú principal
        $menuPrincipal = new MenuElement();
        $menuPrincipal->setNombre('Streaming');
        $menuPrincipal->setIcon('fas fa-play-circle');
        $menuPrincipal->setType('menu');
        $menuPrincipal->setParentId(0);
        $menuPrincipal->setRuta('/streaming');
        $menuPrincipal->setEnabled(true);
        $menuPrincipal->addModulo($modulo);
        
        $this->entityManager->persist($menuPrincipal);
        
        // Submenú - Populares
        $menuPopular = new MenuElement();
        $menuPopular->setNombre('Populares');
        $menuPopular->setIcon('fas fa-fire');
        $menuPopular->setType('menu');
        $menuPopular->setParentId($menuPrincipal->getId() ?? 0);
        $menuPopular->setRuta('/streaming/popular');
        $menuPopular->setEnabled(true);
        $menuPopular->addModulo($modulo);
        
        $this->entityManager->persist($menuPopular);
        
        // Submenú - En Directo
        $menuLive = new MenuElement();
        $menuLive->setNombre('En Directo');
        $menuLive->setIcon('fas fa-broadcast-tower');
        $menuLive->setType('menu');
        $menuLive->setParentId($menuPrincipal->getId() ?? 0);
        $menuLive->setRuta('/streaming/type/live');
        $menuLive->setEnabled(true);
        $menuLive->addModulo($modulo);
        
        $this->entityManager->persist($menuLive);
        
        // Submenú - Bajo Demanda
        $menuOnDemand = new MenuElement();
        $menuOnDemand->setNombre('Bajo Demanda');
        $menuOnDemand->setIcon('fas fa-film');
        $menuOnDemand->setType('menu');
        $menuOnDemand->setParentId($menuPrincipal->getId() ?? 0);
        $menuOnDemand->setRuta('/streaming/type/ondemand');
        $menuOnDemand->setEnabled(true);
        $menuOnDemand->addModulo($modulo);
        
        $this->entityManager->persist($menuOnDemand);
        
        // Finalizar instalación
        $this->entityManager->flush();
    }
    
    public function uninstall(): void
    {
        // Buscar el módulo
        $moduloRepository = $this->entityManager->getRepository(Modulo::class);
        $modulo = $moduloRepository->findOneBy(['nombre' => 'Streaming']);
        
        if (!$modulo) {
            return; // No está instalado
        }
        
        // Desactivar el módulo en lugar de borrarlo
        $modulo->setEstado(false);
        $modulo->setUninstallDate(new \DateTimeImmutable());
        
        // Desactivar elementos de menú asociados
        $menuElements = $modulo->getMenuElements();
        foreach ($menuElements as $menuElement) {
            $menuElement->setEnabled(false);
        }
        
        $this->entityManager->flush();
    }
    
    public function isInstalled(): bool
    {
        $moduloRepository = $this->entityManager->getRepository(Modulo::class);
        $modulo = $moduloRepository->findOneBy(['nombre' => 'Streaming', 'estado' => true]);
        
        return $modulo !== null;
    }
}