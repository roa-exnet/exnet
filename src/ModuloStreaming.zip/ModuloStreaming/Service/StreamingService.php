<?php

namespace App\ModuloStreaming\Service;

class StreamingService
{
    public function __construct()
    {
        // Constructor vacío
    }
    
    /**
     * Obtiene la lista de videos disponibles
     */
    public function getAvailableVideos(): array
    {
        return [];
    }
}