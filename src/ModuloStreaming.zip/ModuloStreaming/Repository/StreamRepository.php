<?php

namespace App\ModuloStreaming\Repository;

use App\ModuloStreaming\Entity\Stream;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Stream>
 */
class StreamRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Stream::class);
    }

    /**
     * @return Stream[] Returns an array of active Stream objects
     */
    public function findActiveStreams(): array
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.active = :active')
            ->setParameter('active', true)
            ->orderBy('s.created_at', 'DESC')
            ->getQuery()
            ->getResult();
    }
    
    /**
     * @return Stream[] Returns an array of active Stream objects by type
     */
    public function findByType(string $type): array
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.streamType = :type')
            ->andWhere('s.active = :active')
            ->setParameter('type', $type)
            ->setParameter('active', true)
            ->orderBy('s.created_at', 'DESC')
            ->getQuery()
            ->getResult();
    }
    
    /**
     * @return Stream[] Returns an array of active Stream objects by category
     */
    public function findByCategory(string $category): array
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.category = :category')
            ->andWhere('s.active = :active')
            ->setParameter('category', $category)
            ->setParameter('active', true)
            ->orderBy('s.created_at', 'DESC')
            ->getQuery()
            ->getResult();
    }
    
    /**
     * @return Stream[] Returns the most viewed streams
     */
    public function findMostViewed(int $limit = 10): array
    {
        return $this->createQueryBuilder('s')
            ->andWhere('s.active = :active')
            ->setParameter('active', true)
            ->orderBy('s.viewCount', 'DESC')
            ->setMaxResults($limit)
            ->getQuery()
            ->getResult();
    }
}