<?php

namespace App\ModuloStreaming\Command;

use App\ModuloStreaming\Service\StreamingModuleConfigurator;
use Symfony\Component\Console\Attribute\AsCommand;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Component\Console\Style\SymfonyStyle;

#[AsCommand(
    name: 'app:module:streaming',
    description: 'Gestiona el módulo de Streaming',
)]
class StreamingModuleCommand extends Command
{
    private StreamingModuleConfigurator $configurator;

    public function __construct(StreamingModuleConfigurator $configurator)
    {
        parent::__construct();
        $this->configurator = $configurator;
    }

    protected function configure(): void
    {
        $this
            ->addOption('install', 'i', InputOption::VALUE_NONE, 'Instalar el módulo de Streaming')
            ->addOption('uninstall', 'u', InputOption::VALUE_NONE, 'Desinstalar el módulo de Streaming')
            ->addOption('status', 's', InputOption::VALUE_NONE, 'Verificar el estado del módulo de Streaming')
            ->setHelp(<<<EOT
                El comando <info>app:module:streaming</info> te permite gestionar el módulo de Streaming:

                <info>php bin/console app:module:streaming --install</info>   Instala el módulo y sus menús
                <info>php bin/console app:module:streaming --uninstall</info> Desinstala el módulo (desactiva)
                <info>php bin/console app:module:streaming --status</info>    Muestra el estado actual
                EOT
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $io = new SymfonyStyle($input, $output);
        
        if ($input->getOption('install')) {
            $io->title('Instalando módulo de Streaming');
            
            if ($this->configurator->isInstalled()) {
                $io->warning('El módulo de Streaming ya está instalado.');
                return Command::SUCCESS;
            }
            
            try {
                $this->configurator->install();
                $io->success('Módulo de Streaming instalado correctamente.');
                $io->text('Ahora puedes acceder a /streaming en tu navegador.');
                return Command::SUCCESS;
            } catch (\Exception $e) {
                $io->error('Error al instalar el módulo: ' . $e->getMessage());
                return Command::FAILURE;
            }
        }
        
        if ($input->getOption('uninstall')) {
            $io->title('Desinstalando módulo de Streaming');
            
            if (!$this->configurator->isInstalled()) {
                $io->warning('El módulo de Streaming no está instalado.');
                return Command::SUCCESS;
            }
            
            try {
                $this->configurator->uninstall();
                $io->success('Módulo de Streaming desinstalado correctamente.');
                return Command::SUCCESS;
            } catch (\Exception $e) {
                $io->error('Error al desinstalar el módulo: ' . $e->getMessage());
                return Command::FAILURE;
            }
        }
        
        if ($input->getOption('status')) {
            $io->title('Estado del módulo de Streaming');
            
            if ($this->configurator->isInstalled()) {
                $io->info('El módulo de Streaming está INSTALADO y ACTIVO.');
            } else {
                $io->info('El módulo de Streaming NO está instalado o está INACTIVO.');
            }
            
            return Command::SUCCESS;
        }
        
        $io->text([
            'Por favor, especifica una acción:',
            '',
            '  --install    Instalar el módulo',
            '  --uninstall  Desinstalar el módulo',
            '  --status     Ver el estado actual',
            '',
            'Ejemplo: php bin/console app:module:streaming --install',
        ]);
        
        return Command::SUCCESS;
    }
}