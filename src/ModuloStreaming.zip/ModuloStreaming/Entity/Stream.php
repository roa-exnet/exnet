<?php

namespace App\ModuloStreaming\Entity;

use App\ModuloStreaming\Repository\StreamRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: StreamRepository::class)]
class Stream
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $title = null;

    #[ORM\Column(length: 255)]
    private ?string $description = null;
    
    #[ORM\Column(length: 255)]
    private ?string $url = null;
    
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $thumbnail = null;
    
    #[ORM\Column]
    private ?bool $active = null;
    
    #[ORM\Column]
    private ?\DateTimeImmutable $created_at = null;
    
    #[ORM\Column(length: 50)]
    private ?string $streamType = null;
    
    #[ORM\Column(length: 255, nullable: true)]
    private ?string $category = null;
    
    #[ORM\Column(nullable: true)]
    private ?int $viewCount = 0;

    public function __construct()
    {
        $this->created_at = new \DateTimeImmutable();
        $this->active = true;
        $this->viewCount = 0;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getTitle(): ?string
    {
        return $this->title;
    }

    public function setTitle(string $title): static
    {
        $this->title = $title;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): static
    {
        $this->description = $description;

        return $this;
    }
    
    public function getUrl(): ?string
    {
        return $this->url;
    }
    
    public function setUrl(string $url): static
    {
        $this->url = $url;
        
        return $this;
    }
    
    public function getThumbnail(): ?string
    {
        return $this->thumbnail;
    }
    
    public function setThumbnail(?string $thumbnail): static
    {
        $this->thumbnail = $thumbnail;
        
        return $this;
    }
    
    public function isActive(): ?bool
    {
        return $this->active;
    }
    
    public function setActive(bool $active): static
    {
        $this->active = $active;
        
        return $this;
    }
    
    public function getCreatedAt(): ?\DateTimeImmutable
    {
        return $this->created_at;
    }
    
    public function setCreatedAt(\DateTimeImmutable $created_at): static
    {
        $this->created_at = $created_at;
        
        return $this;
    }
    
    public function getStreamType(): ?string
    {
        return $this->streamType;
    }
    
    public function setStreamType(string $streamType): static
    {
        $this->streamType = $streamType;
        
        return $this;
    }
    
    public function getCategory(): ?string
    {
        return $this->category;
    }
    
    public function setCategory(?string $category): static
    {
        $this->category = $category;
        
        return $this;
    }
    
    public function getViewCount(): ?int
    {
        return $this->viewCount;
    }
    
    public function setViewCount(?int $viewCount): static
    {
        $this->viewCount = $viewCount;
        
        return $this;
    }
    
    public function incrementViewCount(): static
    {
        $this->viewCount = ($this->viewCount ?? 0) + 1;
        
        return $this;
    }
}