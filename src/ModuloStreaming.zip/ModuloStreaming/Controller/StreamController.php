<?php

namespace App\ModuloStreaming\Controller;

use App\ModuloStreaming\Entity\Stream;
use App\ModuloStreaming\Form\StreamType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Mercure\HubInterface;
use Symfony\Component\Mercure\Update;
use Symfony\Component\Serializer\SerializerInterface;

#[Route('/streaming')]
class StreamingController extends AbstractController
{
    private EntityManagerInterface $entityManager;
    private SerializerInterface $serializer;
    private HubInterface $hub;

    public function __construct(
        EntityManagerInterface $entityManager,
        SerializerInterface $serializer,
        HubInterface $hub
    ) {
        $this->entityManager = $entityManager;
        $this->serializer = $serializer;
        $this->hub = $hub;
    }

    #[Route('/', name: 'app_streaming_index', methods: ['GET'])]
    public function index(): Response
    {
        $streams = $this->entityManager
            ->getRepository(Stream::class)
            ->findActiveStreams();

        return $this->render('ModuloStreaming/index.html.twig', [
            'streams' => $streams,
        ]);
    }

    #[Route('/category/{category}', name: 'app_streaming_category', methods: ['GET'])]
    public function category(string $category): Response
    {
        $streams = $this->entityManager
            ->getRepository(Stream::class)
            ->findByCategory($category);

        return $this->render('ModuloStreaming/category.html.twig', [
            'streams' => $streams,
            'category' => $category,
        ]);
    }

    #[Route('/type/{type}', name: 'app_streaming_type', methods: ['GET'])]
    public function type(string $type): Response
    {
        $streams = $this->entityManager
            ->getRepository(Stream::class)
            ->findByType($type);

        return $this->render('ModuloStreaming/type.html.twig', [
            'streams' => $streams,
            'type' => $type,
        ]);
    }

    #[Route('/view/{id}', name: 'app_streaming_view', methods: ['GET'])]
    public function view(Stream $stream): Response
    {
        // Incrementar contador de visitas
        $stream->incrementViewCount();
        $this->entityManager->flush();

        return $this->render('ModuloStreaming/view.html.twig', [
            'stream' => $stream,
        ]);
    }

    #[Route('/new', name: 'app_streaming_new', methods: ['GET', 'POST'])]
    public function new(Request $request): Response
    {
        $stream = new Stream();
        $form = $this->createForm(StreamType::class, $stream);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->persist($stream);
            $this->entityManager->flush();

            // Publicar actualización mediante Mercure
            $update = new Update(
                'https://example.com/streaming',
                $this->serializer->serialize(['action' => 'created', 'stream' => $stream], 'json')
            );
            $this->hub->publish($update);

            return $this->redirectToRoute('app_streaming_index');
        }

        return $this->render('ModuloStreaming/new.html.twig', [
            'stream' => $stream,
            'form' => $form,
        ]);
    }

    #[Route('/{id}/edit', name: 'app_streaming_edit', methods: ['GET', 'POST'])]
    public function edit(Request $request, Stream $stream): Response
    {
        $form = $this->createForm(StreamType::class, $stream);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->entityManager->flush();

            return $this->redirectToRoute('app_streaming_index');
        }

        return $this->render('ModuloStreaming/edit.html.twig', [
            'stream' => $stream,
            'form' => $form,
        ]);
    }

    #[Route('/{id}', name: 'app_streaming_delete', methods: ['POST'])]
    public function delete(Request $request, Stream $stream): Response
    {
        if ($this->isCsrfTokenValid('delete'.$stream->getId(), $request->request->get('_token'))) {
            $stream->setActive(false);
            $this->entityManager->flush();
        }

        return $this->redirectToRoute('app_streaming_index');
    }
    
    #[Route('/popular', name: 'app_streaming_popular', methods: ['GET'])]
    public function popular(): Response
    {
        $streams = $this->entityManager
            ->getRepository(Stream::class)
            ->findMostViewed(10);

        return $this->render('ModuloStreaming/popular.html.twig', [
            'streams' => $streams,
        ]);
    }
}