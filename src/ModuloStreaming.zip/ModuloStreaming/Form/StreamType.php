<?php

namespace App\ModuloStreaming\Form;

use App\ModuloStreaming\Entity\Stream;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class StreamType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('title', TextType::class, [
                'label' => 'Título',
                'attr' => [
                    'class' => 'form-control',
                    'placeholder' => 'Título del stream'
                ]
            ])
            ->add('description', TextareaType::class, [
                'label' => 'Descripción',
                'attr' => [
                    'class' => 'form-control',
                    'placeholder' => 'Describe el contenido del stream',
                    'rows' => 4
                ]
            ])
            ->add('url', UrlType::class, [
                'label' => 'URL del Stream',
                'attr' => [
                    'class' => 'form-control',
                    'placeholder' => 'https://ejemplo.com/stream'
                ]
            ])
            ->add('thumbnail', UrlType::class, [
                'label' => 'URL de la miniatura',
                'required' => false,
                'attr' => [
                    'class' => 'form-control',
                    'placeholder' => 'https://ejemplo.com/thumbnail.jpg'
                ]
            ])
            ->add('streamType', ChoiceType::class, [
                'label' => 'Tipo de Stream',
                'choices' => [
                    'Directo' => 'live',
                    'Bajo Demanda' => 'ondemand',
                    'Evento Programado' => 'scheduled'
                ],
                'attr' => ['class' => 'form-select']
            ])
            ->add('category', ChoiceType::class, [
                'label' => 'Categoría',
                'choices' => [
                    'Educación' => 'education',
                    'Entretenimiento' => 'entertainment',
                    'Deportes' => 'sports',
                    'Noticias' => 'news',
                    'Música' => 'music',
                    'Gaming' => 'gaming',
                    'Otros' => 'others'
                ],
                'attr' => ['class' => 'form-select']
            ])
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Stream::class,
        ]);
    }
}