<?php

namespace App\ModuloCore\Service;

use Doctrine\DBAL\Connection;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class KeycloakModuleService
{
    private string $apiUrl;

    public function __construct(
        private Connection $conn,
        private HttpClientInterface $httpClient
    ) {
        $this->apiUrl = $_ENV['API_URL'] ?? '';
    }

    public function registrarLicencia(string $modulo, string $realm): array
    {
        $existe = $this->conn->fetchOne('SELECT COUNT(*) FROM licencia WHERE nombre = :nombre', [
            'nombre' => $modulo
        ]);

        if ($existe > 0) {
            return ['success' => true, 'message' => 'Licencia ya registrada'];
        }

        $response = $this->httpClient->request('POST', $this->apiUrl . '/crear-cliente', [
            'json' => [
                'realm' => $realm,
                'client_id' => $modulo,
                'lifespan' => 31536000
            ]
        ]);

        $data = $response->toArray(false);
        if (!isset($data['access_token'])) {
            return ['success' => false, 'error' => 'No se recibió token'];
        }

        $this->conn->insert('licencia', [
            'nombre' => $modulo,
            'token' => $data['access_token']
        ]);

        return ['success' => true, 'token' => $data['access_token']];
    }
}