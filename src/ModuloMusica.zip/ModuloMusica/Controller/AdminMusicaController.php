<?php

namespace App\ModuloMusica\Controller;

use App\ModuloCore\Service\IpAuthService;
use App\ModuloMusica\Entity\Cancion;
use App\ModuloMusica\Entity\Genero;
use App\ModuloMusica\Repository\CancionRepository;
use App\ModuloMusica\Repository\GeneroRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\String\Slugger\SluggerInterface;

#[Route('/musica/admin')]
class AdminMusicaController extends AbstractController
{
    private EntityManagerInterface $entityManager;
    private IpAuthService $ipAuthService;
    private CancionRepository $cancionRepository;
    private GeneroRepository $generoRepository;
    private SluggerInterface $slugger;
    private string $uploadsDirectory;

    public function __construct(
        EntityManagerInterface $entityManager,
        IpAuthService $ipAuthService,
        CancionRepository $cancionRepository,
        GeneroRepository $generoRepository,
        SluggerInterface $slugger,
        string $uploadsDirectory = '%kernel.project_dir%/src/ModuloMusica/Assets'
    ) {
        $this->entityManager = $entityManager;
        $this->ipAuthService = $ipAuthService;
        $this->cancionRepository = $cancionRepository;
        $this->generoRepository = $generoRepository;
        $this->slugger = $slugger;
        // Elimina las comillas del valor del parámetro si es necesario
        $this->uploadsDirectory = str_replace('\'', '', $uploadsDirectory);
    }

    private function checkAdmin(): ?Response
    {
        $user = $this->ipAuthService->getCurrentUser();
        if (!$user) {
            return $this->redirectToRoute('app_register_ip', [
                'redirect' => $this->generateUrl('musica_admin')
            ]);
        }

        if (!in_array('ROLE_ADMIN', $user->getRoles())) {
            throw $this->createAccessDeniedException('No tienes permisos para acceder a esta sección');
        }

        return null;
    }

    #[Route('/nueva-cancion', name: 'musica_admin_nueva_cancion')]
    public function nuevaCancion(Request $request): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        $cancion = new Cancion();
        $generos = $this->generoRepository->findAllOrdered();

        if ($request->isMethod('POST')) {
            $titulo = $request->request->get('titulo');
            $artista = $request->request->get('artista');
            $album = $request->request->get('album');
            $descripcion = $request->request->get('descripcion');
            $imagen = $request->request->get('imagen');
            $generoId = $request->request->get('genero');
            $anio = $request->request->get('anio');
            $duracion = $request->request->get('duracion');
            $esPublico = $request->request->has('esPublico');

            $cancion->setTitulo($titulo);
            $cancion->setArtista($artista);
            $cancion->setAlbum($album);
            $cancion->setDescripcion($descripcion);
            $cancion->setImagen($imagen);
            $cancion->setAnio($anio ? (int)$anio : null);
            $cancion->setDuracion($duracion ? (int)$duracion : null);
            $cancion->setEsPublico($esPublico);

            // Manejo del archivo de audio
            $audioFile = $request->files->get('audioFile');
            if ($audioFile) {
                // Obtener información del archivo original
                $originalFilename = pathinfo($audioFile->getClientOriginalName(), PATHINFO_FILENAME);
                $originalExtension = pathinfo($audioFile->getClientOriginalName(), PATHINFO_EXTENSION);
                
                // Usar preferentemente la extensión original del archivo
                $extension = $originalExtension;
                
                // Si no hay extensión original, determinarla por el MIME type
                if (empty($extension)) {
                    $mimeType = $audioFile->getMimeType();
                    switch ($mimeType) {
                        case 'audio/mpeg': $extension = 'mp3'; break;
                        case 'audio/mp4': case 'audio/m4a': $extension = 'm4a'; break;
                        case 'audio/ogg': $extension = 'ogg'; break;
                        case 'audio/wav': case 'audio/x-wav': $extension = 'wav'; break;
                        default: $extension = 'mp3'; // valor predeterminado
                    }
                }
                
                // Asegurarnos de que tenemos una extensión válida
                if (empty($extension)) {
                    $extension = 'mp3'; // Si todo lo anterior falla, usar mp3 como predeterminado
                }
                
                $safeFilename = $this->slugger->slug($originalFilename);
                $newFilename = $safeFilename.'-'.uniqid().'.'.$extension;
                
                try {
                    // Usar directamente el método getUploadsPath()
                    $uploadsDir = $this->getUploadsPath();
                    
                    // Eliminar el archivo anterior si existe
                    $oldUrl = $cancion->getUrl();
                    if ($oldUrl && strpos($oldUrl, '/ModuloMusica/music/') === 0) {
                        $oldFilename = basename($oldUrl);
                        $oldFilePath = $uploadsDir . '/' . $oldFilename;
                        if (file_exists($oldFilePath)) {
                            unlink($oldFilePath);
                        }
                    }
                    
                    // Mover el archivo
                    $audioFile->move($uploadsDir, $newFilename);
                    
                    // Guardar la URL relativa en la entidad
                    $cancion->setUrl('/ModuloMusica/music/' . $newFilename);
                } catch (\Exception $e) {
                    error_log('Error al subir archivo: ' . $e->getMessage() . "\n" . $e->getTraceAsString());
                    $this->addFlash('error', 'Error al subir el archivo de audio: ' . $e->getMessage());
                    return $this->render('@ModuloMusica/admin/editar_cancion.html.twig', [
                        'cancion' => $cancion,
                        'generos' => $generos,
                        'user' => $this->ipAuthService->getCurrentUser()
                    ]);
                }
            }

            if ($generoId) {
                $genero = $this->generoRepository->find($generoId);
                if ($genero) {
                    $cancion->setGenero($genero);
                }
            }

            $this->entityManager->persist($cancion);
            $this->entityManager->flush();

            $this->addFlash('success', 'Canción creada correctamente.');
            return $this->redirectToRoute('musica_admin');
        }

        return $this->render('@ModuloMusica/admin/nueva_cancion.html.twig', [
            'cancion' => $cancion,
            'generos' => $generos,
            'user' => $this->ipAuthService->getCurrentUser()
        ]);
    }

    #[Route('/editar-cancion/{id}', name: 'musica_admin_editar_cancion')]
    public function editarCancion(int $id, Request $request): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        $cancion = $this->cancionRepository->find($id);
        if (!$cancion) {
            throw $this->createNotFoundException('La canción no existe');
        }

        $generos = $this->generoRepository->findAllOrdered();

        if ($request->isMethod('POST')) {
            $titulo = $request->request->get('titulo');
            $artista = $request->request->get('artista');
            $album = $request->request->get('album');
            $descripcion = $request->request->get('descripcion');
            $imagen = $request->request->get('imagen');
            $generoId = $request->request->get('genero');
            $anio = $request->request->get('anio');
            $duracion = $request->request->get('duracion');
            $esPublico = $request->request->has('esPublico');
            $mantenerAudio = $request->request->has('mantenerAudio');

            $cancion->setTitulo($titulo);
            $cancion->setArtista($artista);
            $cancion->setAlbum($album);
            $cancion->setDescripcion($descripcion);
            $cancion->setImagen($imagen);
            $cancion->setAnio($anio ? (int)$anio : null);
            $cancion->setDuracion($duracion ? (int)$duracion : null);
            $cancion->setEsPublico($esPublico);
            $cancion->setActualizadoEn(new \DateTimeImmutable());

            // Manejo del archivo de audio
            $audioFile = $request->files->get('audioFile');
            if ($audioFile) {
                $originalFilename = pathinfo($audioFile->getClientOriginalName(), PATHINFO_FILENAME);
                $safeFilename = $this->slugger->slug($originalFilename);
                $newFilename = $safeFilename.'-'.uniqid().'.'.$audioFile->guessExtension();

                try {
                    // Mover el archivo al directorio de uploads
                    $uploadsDir = $this->getUploadsPath();
                    if (!is_dir($uploadsDir)) {
                        mkdir($uploadsDir, 0755, true);
                    }
                    
                    $audioFile->move($uploadsDir, $newFilename);
                    
                    // Eliminar el archivo anterior si existe
                    $oldUrl = $cancion->getUrl();
                    if ($oldUrl && strpos($oldUrl, '/ModuloMusica/music/') === 0) {
                        $oldFilename = basename($oldUrl);
                        $oldFilePath = $uploadsDir . '/' . $oldFilename;
                        if (file_exists($oldFilePath)) {
                            unlink($oldFilePath);
                        }
                    }
                    
                    // Guardar la URL relativa en la entidad
                    $cancion->setUrl('/ModuloMusica/music/' . $newFilename);
                } catch (\Exception $e) {
                    $this->addFlash('error', 'Error al subir el archivo de audio: ' . $e->getMessage());
                    return $this->render('@ModuloMusica/admin/editar_cancion.html.twig', [
                        'cancion' => $cancion,
                        'generos' => $generos,
                        'user' => $this->ipAuthService->getCurrentUser()
                    ]);
                }
            } elseif (!$mantenerAudio) {
                // Si no se mantiene el audio actual y no se sube uno nuevo, eliminar la URL
                $oldUrl = $cancion->getUrl();
                if ($oldUrl && strpos($oldUrl, '/ModuloMusica/music/') === 0) {
                    $oldFilename = basename($oldUrl);
                    $oldFilePath = $this->getUploadsPath() . '/' . $oldFilename;
                    if (file_exists($oldFilePath)) {
                        unlink($oldFilePath);
                    }
                }
                $cancion->setUrl(null);
            }

            if ($generoId) {
                $genero = $this->generoRepository->find($generoId);
                if ($genero) {
                    $cancion->setGenero($genero);
                }
            } else {
                $cancion->setGenero(null);
            }

            $this->entityManager->flush();

            $this->addFlash('success', 'Canción actualizada correctamente.');
            return $this->redirectToRoute('musica_admin');
        }

        return $this->render('@ModuloMusica/admin/editar_cancion.html.twig', [
            'cancion' => $cancion,
            'generos' => $generos,
            'user' => $this->ipAuthService->getCurrentUser()
        ]);
    }

    #[Route('/eliminar-cancion/{id}', name: 'musica_admin_eliminar_cancion', methods: ['POST'])]
    public function eliminarCancion(int $id): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        $cancion = $this->cancionRepository->find($id);
        if (!$cancion) {
            throw $this->createNotFoundException('La canción no existe');
        }

        // Eliminar el archivo si existe
        $url = $cancion->getUrl();
        if ($url && strpos($url, '/ModuloMusica/music/') === 0) {
            $filename = basename($url);
            $filePath = $this->getUploadsPath() . '/' . $filename;
            if (file_exists($filePath)) {
                unlink($filePath);
            }
        }

        $this->entityManager->remove($cancion);
        $this->entityManager->flush();

        $this->addFlash('success', 'Canción eliminada correctamente.');
        return $this->redirectToRoute('musica_admin');
    }

    #[Route('/nuevo-genero', name: 'musica_admin_nuevo_genero')]
    public function nuevoGenero(Request $request): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        if ($request->isMethod('POST')) {
            $nombre = $request->request->get('nombre');
            $descripcion = $request->request->get('descripcion');
            $icono = $request->request->get('icono');

            $genero = new Genero();
            $genero->setNombre($nombre);
            $genero->setDescripcion($descripcion);
            $genero->setIcono($icono);

            $this->entityManager->persist($genero);
            $this->entityManager->flush();

            $this->addFlash('success', 'Género creado correctamente.');
            return $this->redirectToRoute('musica_admin');
        }

        return $this->render('@ModuloMusica/admin/nuevo_genero.html.twig', [
            'user' => $this->ipAuthService->getCurrentUser()
        ]);
    }

    #[Route('/editar-genero/{id}', name: 'musica_admin_editar_genero')]
    public function editarGenero(int $id, Request $request): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        $genero = $this->generoRepository->find($id);
        if (!$genero) {
            throw $this->createNotFoundException('El género no existe');
        }

        if ($request->isMethod('POST')) {
            $nombre = $request->request->get('nombre');
            $descripcion = $request->request->get('descripcion');
            $icono = $request->request->get('icono');

            $genero->setNombre($nombre);
            $genero->setDescripcion($descripcion);
            $genero->setIcono($icono);

            $this->entityManager->flush();

            $this->addFlash('success', 'Género actualizado correctamente.');
            return $this->redirectToRoute('musica_admin');
        }

        return $this->render('@ModuloMusica/admin/editar_genero.html.twig', [
            'genero' => $genero,
            'user' => $this->ipAuthService->getCurrentUser()
        ]);
    }

    #[Route('/eliminar-genero/{id}', name: 'musica_admin_eliminar_genero', methods: ['POST'])]
    public function eliminarGenero(int $id): Response
    {
        $checkResult = $this->checkAdmin();
        if ($checkResult) {
            return $checkResult;
        }

        $genero = $this->generoRepository->find($id);
        if (!$genero) {
            throw $this->createNotFoundException('El género no existe');
        }

        if (!$genero->getCanciones()->isEmpty()) {
            $this->addFlash('error', 'No se puede eliminar el género porque tiene canciones asociadas.');
            return $this->redirectToRoute('musica_admin');
        }

        $this->entityManager->remove($genero);
        $this->entityManager->flush();

        $this->addFlash('success', 'Género eliminado correctamente.');
        return $this->redirectToRoute('musica_admin');
    }
    
    /**
     * Obtiene la ruta al directorio de uploads para archivos de música
     */
    private function getUploadsPath(): string 
    {
        // Asegurarse de que esta variable tenga un valor correcto
        $projectDir = $this->getParameter('kernel.project_dir');
        
        // Crear la ruta completa
        $musicPath = $projectDir . '/src/ModuloMusica/Assets/music';
        
        // Depuración
        error_log('Directorio de subida: ' . $musicPath);
        
        // Asegurarse de que la carpeta existe
        if (!is_dir($musicPath)) {
            if (!mkdir($musicPath, 0755, true)) {
                throw new \RuntimeException('No se pudo crear el directorio de subida: ' . $musicPath);
            }
        }
        
        // Verificar permisos
        if (!is_writable($musicPath)) {
            throw new \RuntimeException('El directorio no tiene permisos de escritura: ' . $musicPath);
        }
        
        return $musicPath;
    }
}